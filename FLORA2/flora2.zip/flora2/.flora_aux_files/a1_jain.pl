
:-(compiler_options([xpp_on,canonical])).

/********** Tabling and Trailer Control Variables ************/

#define EQUALITYnone
#define INHERITANCEflogic
#define TABLINGreactive
#define TABLINGvariant
#define CUSTOMnone

#define FLORA_INCREMENTAL_TABLING 

/************************************************************************
  file: headerinc/flrheader_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).
#mode standard Prolog

#include "flrheader.flh"
#include "flora_porting.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrheader_prog_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).
#mode standard Prolog

#include "flrheader_prog.flh"

/***********************************************************************/

#define FLORA_COMPILATION_ID 1

/************************************************************************
  file: headerinc/flrheader2_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
  It has files that must be included in the header and typically
  contain some Prolog statements. Such files cannot appear
  in flrheader.flh because flrheader.flh is included in various restricted
  contexts where Prolog statements are not allowed.

  NOT included in ADDED files (compiled for addition) -- only in LOADED
  ones and in trailers/patch
************************************************************************/

:-(compiler_options([xpp_on])).

#define TABLING_CONNECTIVE  :-

%% flora_tabling_methods is included here to affect preprocessing of
%% flrtable/flrhilogtable.flh dynamically
#include "flora_tabling_methods.flh"

/* note: inside flrtable.flh there are checks for FLORA_NONTABLED_DATA_MODULE
   that exclude tabling non-signature molecules
*/
#ifndef FLORA_NONTABLED_MODULE
#include "flrtable.flh"
#endif

/* if normal tabled module, then table hilog */
#if !defined(FLORA_NONTABLED_DATA_MODULE) && !defined(FLORA_NONTABLED_MODULE)
#include "flrhilogtable.flh"
#endif

#include "flrtable_always.flh"

#include "flrauxtables.flh"

%% include list of tabled predicates
#mode save
#mode nocomment "%"
#if defined(FLORA_FLT_FILENAME)
#include FLORA_FLT_FILENAME
#endif
#mode restore

/***********************************************************************/

/************************************************************************
  file: headerinc/flrdyna_inc.flh

  Author(s): Chang Zhao

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#define TABLING_CONNECTIVE  :-

#include "flrdyndeclare.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrindex_P_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#include "flrindex_P.flh"

/***********************************************************************/

#mode save
#mode nocomment "%"
#define FLORA_THIS_FILENAME  'a1_jain.flr'
#mode restore
/************************************************************************
  file: headerinc/flrdefinition_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

#include "flrdefinition.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrtrailerregistry_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

#include "flrtrailerregistry.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrrefreshtable_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#include "flrrefreshtable.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrdynamic_connectors_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#include "flrdynamic_connectors.flh"

/***********************************************************************/

/************************************************************************
  file: syslibinc/flrimportedcalls_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the FLORA-2 compiler.
************************************************************************/

%% Loads the file with all the import statements for predicates
%% that must be known everywhere

:-(compiler_options([xpp_on])).

#mode standard Prolog

#if !defined(FLORA_TERMS_FLH)
#define FLORA_TERMS_FLH
#include "flora_terms.flh"
#endif

?-(:(flrlibman,flora_load_library(FLLIBIMPORTEDCALLS))).

/***********************************************************************/

/************************************************************************
  file: headerinc/flrpatch_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

#include "flrexportcheck.flh"
#include "flrpatch.flh"
/***********************************************************************/

/************************************************************************
  file: headerinc/flropposes_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

#include "flropposes.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrhead_dispatch_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#include "flrhead_dispatch.flh"

/***********************************************************************/

/************************************************************************
  file: syslibinc/flranswer_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the FLORA-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#mode standard Prolog

#if !defined(FLORA_TERMS_FLH)
#define FLORA_TERMS_FLH
#include "flora_terms.flh"
#endif

?-(:(flrlibman,flora_load_library(FLLIBANSWER))).

/***********************************************************************/

/************************************************************************
  file: syslibinc/flrclause_inc.flh

  Author(s): Chang Zhao

  This file is automatically included by the FLORA-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#mode standard Prolog

#if !defined(FLORA_TERMS_FLH)
#define FLORA_TERMS_FLH
#include "flora_terms.flh"
#endif

?-(:(flrlibman,flora_load_library(FLLIBCLAUSE))).

/***********************************************************************/

/************************************************************************
  file: syslibinc/flraggmax_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the FLORA-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#mode standard Prolog

#if !defined(FLORA_TERMS_FLH)
#define FLORA_TERMS_FLH
#include "flora_terms.flh"
#endif

?-(:(flrlibman,flora_load_library(FLLIBMAX))).

/***********************************************************************/

/************************************************************************
  file: syslibinc/flraggsum_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the FLORA-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#mode standard Prolog

#if !defined(FLORA_TERMS_FLH)
#define FLORA_TERMS_FLH
#include "flora_terms.flh"
#endif

?-(:(flrlibman,flora_load_library(FLLIBSUM))).

/***********************************************************************/

/************************************************************************
  file: libinc/flrio_inc.flh

  Author(s): Guizhen Yang

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#mode standard Prolog

#if !defined(FLORA_TERMS_FLH)
#define FLORA_TERMS_FLH
#include "flora_terms.flh"
#endif

?-(':'(flrlibman,flora_load_system_module(FLSYSMODIO))).

/***********************************************************************/

 
#if !defined(FLORA_FDB_FILENAME)
#if !defined(FLORA_LOADDYN_DATA)
#define FLORA_LOADDYN_DATA
#endif
#mode save
#mode nocomment "%"
#define FLORA_FDB_FILENAME  'a1_jain.fdb'
#mode restore
?-(:(flrutils,flora_loaddyn_data(FLORA_FDB_FILENAME,FLORA_THIS_MODULE_NAME,'fdb'))).
#else
#if !defined(FLORA_READ_CANONICAL_AND_INSERT)
#define FLORA_READ_CANONICAL_AND_INSERT
#endif
?-(:(flrutils,flora_read_canonical_and_insert(FLORA_FDB_FILENAME,FLORA_THIS_FDB_STORAGE))).
#endif

 
#if !defined(FLORA_FLM_FILENAME)
#if !defined(FLORA_LOADDYN_DATA)
#define FLORA_LOADDYN_DATA
#endif
#mode save
#mode nocomment "%"
#define FLORA_FLM_FILENAME  'a1_jain.flm'
#mode restore
?-(:(flrutils,flora_loaddyn_data(FLORA_FLM_FILENAME,FLORA_THIS_MODULE_NAME,'flm'))).
#else
#if !defined(FLORA_READ_CANONICAL_AND_INSERT)
#define FLORA_READ_CANONICAL_AND_INSERT
#endif
?-(:(flrutils,flora_read_descriptor_metafacts_canonical_and_insert(a1_jain,_ErrNum))).
#endif

 
#if !defined(FLORA_FLD_FILENAME)
#if !defined(FLORA_LOADDYN_DATA)
#define FLORA_LOADDYN_DATA
#endif
#mode save
#mode nocomment "%"
#define FLORA_FLD_FILENAME  'a1_jain.fld'
#mode restore
?-(:(flrutils,flora_loaddyn_data(FLORA_FLD_FILENAME,FLORA_THIS_MODULE_NAME,'fld'))).
#else
#if !defined(FLORA_READ_CANONICAL_AND_INSERT)
#define FLORA_READ_CANONICAL_AND_INSERT
#endif
?-(:(flrutils,flora_read_canonical_and_insert(FLORA_FLD_FILENAME,FLORA_THIS_FLD_STORAGE))).
#endif

 
#if !defined(FLORA_FLS_FILENAME)
#if !defined(FLORA_LOADDYN_DATA)
#define FLORA_LOADDYN_DATA
#endif
#mode save
#mode nocomment "%"
#define FLORA_FLS_FILENAME  'a1_jain.fls'
#mode restore
?-(:(flrutils,flora_loaddyn_data(FLORA_FLS_FILENAME,FLORA_THIS_MODULE_NAME,'fls'))).
#else
#if !defined(FLORA_READ_CANONICAL_AND_INSERT)
#define FLORA_READ_CANONICAL_AND_INSERT
#endif
?-(:(flrutils,flora_read_symbols_canonical_and_insert(FLORA_FLS_FILENAME,FLORA_THIS_FLS_STORAGE,_SymbolErrNum))).
#endif


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Rules %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:-(FLORA_THIS_WORKSPACE(static^tblflapply)('Q1',__Company,'_$ctxt'(_CallerModuleVar,4,__newcontextvar1)),','('_$_$_flora''rule_enabled'(4,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__Company,__newdontcarevar2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,4)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__CompanyId,__PersonId,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,4)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,__CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,4)),fllibdelayedliteral(>,'a1_jain.flr',156,[__Shares,0])))),fllibexecute_delayed_calls([__Company,__CompanyId,__PersonId,__Shares,__newdontcarevar6],[__Company])))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)('Q2',__Person,__NetWorth,'_$ctxt'(_CallerModuleVar,6,__newcontextvar1)),','('_$_$_flora''rule_enabled'(6,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(fllibsum(__newdontcarevar5,[__Person],','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(person,__PersonId,__Person,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,6)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,___CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,6)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(shareprice,___CompanyId,__Price,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,6)),','(fllibdelayedliteral(>,'a1_jain.flr',164,[__Shares,0]),fllibdelayedliteral('\\is','a1_jain.flr',164,[__newdontcarevar5,*(__Shares,__Price)]))))),fllibexecute_delayed_calls([__Person,__PersonId,__Price,__Shares,__newdontcarevar5,___CompanyId],[])),__newvar6),=(__NetWorth,__newvar6)),fllibexecute_delayed_calls([__NetWorth,__Person,__PersonId,__Price,__Shares,___CompanyId],[__NetWorth,__Person])))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)('Q3',__Company,__TopBoardMember,'_$ctxt'(_CallerModuleVar,8,__newcontextvar1)),','('_$_$_flora''rule_enabled'(8,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__Company,__newdontcarevar2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,8)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__CompanyId,__PersonId,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,8)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,__CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,8)),','(fllibdelayedliteral(>,'a1_jain.flr',173,[__Shares,0]),','(','(fllibmax(__newdontcarevar8,[__CompanyId1],','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,__CompanyId1,__newdontcarevar8,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar6,8)),FLORA_THIS_WORKSPACE(d^tblflapply)(board,__CompanyId1,__PersonId,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar7,8))),fllibexecute_delayed_calls([__CompanyId1,__PersonId,__newdontcarevar8],[])),__newvar9),=(__X,__newvar9)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(person,__PersonId,__TopBoardMember,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar10,8)),=(__Shares,__X))))))),fllibexecute_delayed_calls([__Company,__CompanyId,__CompanyId1,__PersonId,__Shares,__TopBoardMember,__X,__newdontcarevar11],[__Company,__TopBoardMember])))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)('Q4',__Company1,__Company2,'_$ctxt'(_CallerModuleVar,10,__newcontextvar1)),','('_$_$_flora''rule_enabled'(10,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__Id1,__Company1,__newdontcarevar2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,10)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__Id2,__Company2,__newdontcarevar4,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,10)),','(fllibdelayedliteral('!=','a1_jain.flr',185,[__Company1,__Company2]),','(FLORA_THIS_WORKSPACE(d^tblflapply)(industry,__Id1,__Ind1,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar6,10)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(industry,__Id2,__Ind2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar7,10)),','(=(__Ind1,__Ind2),flibnafdelay(flora_naf(FLORA_THIS_WORKSPACE(tabled_unnumber_call)(','(','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__Id2,__newquantvar10,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar8,10)),FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__newquantvar10,__newquantvar15,__newquantvar16,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar9,10))),flibnafdelay(flora_naf(FLORA_THIS_WORKSPACE(tabled_unnumber_call)(','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__Id1,__newquantvar14,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar11,10)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__newquantvar14,__newquantvar15,__newquantvar13,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar12,10)),fllibdelayedliteral(=<,'a1_jain.flr',195,[__newquantvar16,__newquantvar13]))),fllibexecute_delayed_calls([__newquantvar15,__Id1,__newquantvar16,__newquantvar13,__newquantvar14],[]))),[__Id1,__newquantvar15,__newquantvar16,__newquantvar15,__newquantvar16],193,'a1_jain.flr'))),fllibexecute_delayed_calls([__Id1,__Id2,__newquantvar10,__newquantvar13,__newquantvar14,__newquantvar15,__newquantvar16],[]))),[__Id2,__Id2,__Id1,__Id1,__Id1],null,'a1_jain.flr')))))))),fllibexecute_delayed_calls([__Company1,__Company2,__Id1,__Id2,__Ind1,__Ind2,__newdontcarevar17],[__Company1,__Company2])))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)('Q5',__Person,__Company,__Percentage,'_$ctxt'(_CallerModuleVar,12,__newcontextvar1)),','('_$_$_flora''rule_enabled'(12,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(','(fllibsum(__newdontcarevar7,[__Person,__Company],','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(person,__PersonId,__Person,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,12)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__Company,__newdontcarevar3,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,12)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(controls_indirectly,__PersonId,__CompanyId,__Percentage1,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,12)),fllibdelayedliteral('\\is','a1_jain.flr',205,[__newdontcarevar7,*(__Percentage1,100)])))),fllibexecute_delayed_calls([__Company,__CompanyId,__newdontcarevar7,__Percentage1,__Person,__PersonId,__newdontcarevar6],[])),__newvar8),=(__Percentage,__newvar8)),fllibdelayedliteral(>,'a1_jain.flr',206,[__Percentage,10])),fllibexecute_delayed_calls([__Company,__CompanyId,__Percentage,__Percentage1,__Person,__PersonId,__newdontcarevar9],[__Company,__Percentage,__Person])))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)(controls_directly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(_CallerModuleVar,14,__newcontextvar1)),','('_$_$_flora''rule_enabled'(14,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__EntityId,__CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,14)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__newdontcarevar3,__TotShares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,14)),','(fllibdelayedliteral(>,'a1_jain.flr',211,[__Shares,0]),fllibdelayedliteral('\\is','a1_jain.flr',212,[__Percentage,/(__Shares,__TotShares)])))),fllibexecute_delayed_calls([__CompanyId,__EntityId,__Percentage,__Shares,__TotShares,__newdontcarevar5],[__CompanyId,__EntityId,__Percentage])))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)(controls_indirectly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(_CallerModuleVar,16,__newcontextvar1)),','('_$_$_flora''rule_enabled'(16,'a1_jain.flr',FLORA_THIS_MODULE_NAME),FLORA_THIS_WORKSPACE(d^tblflapply)(controls_directly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,16)))).
:-(FLORA_THIS_WORKSPACE(static^tblflapply)(controls_indirectly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(_CallerModuleVar,18,__newcontextvar1)),','('_$_$_flora''rule_enabled'(18,'a1_jain.flr',FLORA_THIS_MODULE_NAME),','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(controls_directly,__EntityId,__Company2Id,__Percentage1,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,18)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(controls_indirectly,__Company2Id,__CompanyId,__Percentage2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,18)),fllibdelayedliteral('\\is','a1_jain.flr',220,[__Percentage,*(__Percentage1,__Percentage2)]))),fllibexecute_delayed_calls([__Company2Id,__CompanyId,__EntityId,__Percentage,__Percentage1,__Percentage2],[__CompanyId,__EntityId,__Percentage])))).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Rule signatures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

?-(fllibinsrulesig(4,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,104,FLORA_THIS_WORKSPACE(d^tblflapply)('Q1',__Company,'_$ctxt'(_CallerModuleVar,4,__newcontextvar1)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__Company,__newdontcarevar2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,4)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__CompanyId,__PersonId,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,4)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,__CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,4)),fllibdelayedliteral(>,'a1_jain.flr',156,[__Shares,0])))),null,'_$_$_flora''rule_enabled'(4,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__Company,__CompanyId,__PersonId,__Shares,__newdontcarevar6],[__Company]),true)).
?-(fllibinsrulesig(6,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,105,FLORA_THIS_WORKSPACE(d^tblflapply)('Q2',__Person,__NetWorth,'_$ctxt'(_CallerModuleVar,6,__newcontextvar1)),','(fllibsum(__newdontcarevar5,[__Person],','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(person,__PersonId,__Person,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,6)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,___CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,6)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(shareprice,___CompanyId,__Price,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,6)),','(fllibdelayedliteral(>,'a1_jain.flr',164,[__Shares,0]),fllibdelayedliteral('\\is','a1_jain.flr',164,[__newdontcarevar5,*(__Shares,__Price)]))))),fllibexecute_delayed_calls([__Person,__PersonId,__Price,__Shares,__newdontcarevar5,___CompanyId],[])),__newvar6),=(__NetWorth,__newvar6)),null,'_$_$_flora''rule_enabled'(6,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__NetWorth,__Person,__PersonId,__Price,__Shares,___CompanyId],[__NetWorth,__Person]),true)).
?-(fllibinsrulesig(8,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,106,FLORA_THIS_WORKSPACE(d^tblflapply)('Q3',__Company,__TopBoardMember,'_$ctxt'(_CallerModuleVar,8,__newcontextvar1)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__Company,__newdontcarevar2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,8)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__CompanyId,__PersonId,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,8)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,__CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,8)),','(fllibdelayedliteral(>,'a1_jain.flr',173,[__Shares,0]),','(','(fllibmax(__newdontcarevar8,[__CompanyId1],','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__PersonId,__CompanyId1,__newdontcarevar8,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar6,8)),FLORA_THIS_WORKSPACE(d^tblflapply)(board,__CompanyId1,__PersonId,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar7,8))),fllibexecute_delayed_calls([__CompanyId1,__PersonId,__newdontcarevar8],[])),__newvar9),=(__X,__newvar9)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(person,__PersonId,__TopBoardMember,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar10,8)),=(__Shares,__X))))))),null,'_$_$_flora''rule_enabled'(8,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__Company,__CompanyId,__CompanyId1,__PersonId,__Shares,__TopBoardMember,__X,__newdontcarevar11],[__Company,__TopBoardMember]),true)).
?-(fllibinsrulesig(10,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,107,FLORA_THIS_WORKSPACE(d^tblflapply)('Q4',__Company1,__Company2,'_$ctxt'(_CallerModuleVar,10,__newcontextvar1)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__Id1,__Company1,__newdontcarevar2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,10)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__Id2,__Company2,__newdontcarevar4,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,10)),','(fllibdelayedliteral('!=','a1_jain.flr',185,[__Company1,__Company2]),','(FLORA_THIS_WORKSPACE(d^tblflapply)(industry,__Id1,__Ind1,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar6,10)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(industry,__Id2,__Ind2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar7,10)),','(=(__Ind1,__Ind2),flibnafdelay(flora_naf(FLORA_THIS_WORKSPACE(tabled_unnumber_call)(','(','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__Id2,__newquantvar10,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar8,10)),FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__newquantvar10,__newquantvar15,__newquantvar16,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar9,10))),flibnafdelay(flora_naf(FLORA_THIS_WORKSPACE(tabled_unnumber_call)(','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(board,__Id1,__newquantvar14,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar11,10)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__newquantvar14,__newquantvar15,__newquantvar13,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar12,10)),fllibdelayedliteral(=<,'a1_jain.flr',195,[__newquantvar16,__newquantvar13]))),fllibexecute_delayed_calls([__newquantvar15,__Id1,__newquantvar16,__newquantvar13,__newquantvar14],[]))),[__Id1,__newquantvar15,__newquantvar16,__newquantvar15,__newquantvar16],193,'a1_jain.flr'))),fllibexecute_delayed_calls([__Id1,__Id2,__newquantvar10,__newquantvar13,__newquantvar14,__newquantvar15,__newquantvar16],[]))),[__Id2,__Id2,__Id1,__Id1,__Id1],null,'a1_jain.flr')))))))),null,'_$_$_flora''rule_enabled'(10,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__Company1,__Company2,__Id1,__Id2,__Ind1,__Ind2,__newdontcarevar17],[__Company1,__Company2]),true)).
?-(fllibinsrulesig(12,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,108,FLORA_THIS_WORKSPACE(d^tblflapply)('Q5',__Person,__Company,__Percentage,'_$ctxt'(_CallerModuleVar,12,__newcontextvar1)),','(','(fllibsum(__newdontcarevar7,[__Person,__Company],','(','(FLORA_THIS_WORKSPACE(d^tblflapply)(person,__PersonId,__Person,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,12)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__Company,__newdontcarevar3,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,12)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(controls_indirectly,__PersonId,__CompanyId,__Percentage1,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar5,12)),fllibdelayedliteral('\\is','a1_jain.flr',205,[__newdontcarevar7,*(__Percentage1,100)])))),fllibexecute_delayed_calls([__Company,__CompanyId,__newdontcarevar7,__Percentage1,__Person,__PersonId,__newdontcarevar6],[])),__newvar8),=(__Percentage,__newvar8)),fllibdelayedliteral(>,'a1_jain.flr',206,[__Percentage,10])),null,'_$_$_flora''rule_enabled'(12,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__Company,__CompanyId,__Percentage,__Percentage1,__Person,__PersonId,__newdontcarevar9],[__Company,__Percentage,__Person]),true)).
?-(fllibinsrulesig(14,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,109,FLORA_THIS_WORKSPACE(d^tblflapply)(controls_directly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(_CallerModuleVar,14,__newcontextvar1)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(owns,__EntityId,__CompanyId,__Shares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,14)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(company,__CompanyId,__newdontcarevar3,__TotShares,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,14)),','(fllibdelayedliteral(>,'a1_jain.flr',211,[__Shares,0]),fllibdelayedliteral('\\is','a1_jain.flr',212,[__Percentage,/(__Shares,__TotShares)])))),null,'_$_$_flora''rule_enabled'(14,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__CompanyId,__EntityId,__Percentage,__Shares,__TotShares,__newdontcarevar5],[__CompanyId,__EntityId,__Percentage]),true)).
?-(fllibinsrulesig(16,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,110,FLORA_THIS_WORKSPACE(d^tblflapply)(controls_indirectly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(_CallerModuleVar,16,__newcontextvar1)),FLORA_THIS_WORKSPACE(d^tblflapply)(controls_directly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,16)),null,'_$_$_flora''rule_enabled'(16,'a1_jain.flr',FLORA_THIS_MODULE_NAME),null,true)).
?-(fllibinsrulesig(18,'a1_jain.flr','_$_$_flora''descr_vars',FLORA_THIS_MODULE_NAME,111,FLORA_THIS_WORKSPACE(d^tblflapply)(controls_indirectly,__EntityId,__CompanyId,__Percentage,'_$ctxt'(_CallerModuleVar,18,__newcontextvar1)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(controls_directly,__EntityId,__Company2Id,__Percentage1,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,18)),','(FLORA_THIS_WORKSPACE(d^tblflapply)(controls_indirectly,__Company2Id,__CompanyId,__Percentage2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar3,18)),fllibdelayedliteral('\\is','a1_jain.flr',220,[__Percentage,*(__Percentage1,__Percentage2)]))),null,'_$_$_flora''rule_enabled'(18,'a1_jain.flr',FLORA_THIS_MODULE_NAME),fllibexecute_delayed_calls([__Company2Id,__CompanyId,__EntityId,__Percentage,__Percentage1,__Percentage2],[__CompanyId,__EntityId,__Percentage]),true)).


%%%%%%%%%%%%%%%%%%%%%%%%% Signatures for latent queries %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%% Queries found in the source file %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

?-(fllibprogramans(','('_$_$_flora''silent_equal'(_CallerModuleVar,FLORA_THIS_MODULE_NAME),writeln('

Expected results 
================')),[])).
?-(fllibprogramans(','('_$_$_flora''silent_equal'(_CallerModuleVar,FLORA_THIS_MODULE_NAME),','(FLORA_WORKSPACE(\\io,d^tblflapply)(writeln,'=== Query 1: all companies that are partially owned by one of their board members  ===','_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,__newcontextvar1)),FLORA_THIS_WORKSPACE(d^tblflapply)('Q1',__Company,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,__newcontextvar3)))),[=('?Company',__Company)])).
?-(fllibprogramans(','('_$_$_flora''silent_equal'(_CallerModuleVar,FLORA_THIS_MODULE_NAME),','(FLORA_WORKSPACE(\\io,d^tblflapply)(writeln,'=== Query 2: find a person networth ===','_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,__newcontextvar1)),FLORA_THIS_WORKSPACE(d^tblflapply)('Q2',__Person,__NetWorth,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,__newcontextvar3)))),[=('?Person',__Person),=('?NetWorth',__NetWorth)])).
?-(fllibprogramans(','('_$_$_flora''silent_equal'(_CallerModuleVar,FLORA_THIS_MODULE_NAME),','(FLORA_WORKSPACE(\\io,d^tblflapply)(writeln,'=== Query 3: find the top board member of the company ===','_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,__newcontextvar1)),FLORA_THIS_WORKSPACE(d^tblflapply)('Q3',__Company,__TopBoardMember,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,__newcontextvar3)))),[=('?Company',__Company),=('?TopBoardMember',__TopBoardMember)])).
?-(fllibprogramans(','('_$_$_flora''silent_equal'(_CallerModuleVar,FLORA_THIS_MODULE_NAME),','(FLORA_WORKSPACE(\\io,d^tblflapply)(writeln,'=== Query 4: find the company1 and company2 pair where company1 dominates company2 ===','_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,__newcontextvar1)),FLORA_THIS_WORKSPACE(d^tblflapply)('Q4',__Company1,__Company2,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,__newcontextvar3)))),[=('?Company1',__Company1),=('?Company2',__Company2)])).
?-(fllibprogramans(','('_$_$_flora''silent_equal'(_CallerModuleVar,FLORA_THIS_MODULE_NAME),','(FLORA_WORKSPACE(\\io,d^tblflapply)(writeln,'=== Query 5: find the person percentage share in the company ===','_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar2,__newcontextvar1)),FLORA_THIS_WORKSPACE(d^tblflapply)('Q5',__Person,__Company,__Percentage,'_$ctxt'(FLORA_THIS_MODULE_NAME,__newcontextvar4,__newcontextvar3)))),[=('?Person',__Person),=('?Company',__Company),=('?Percentage',__Percentage)])).

 
#if !defined(FLORA_FLS2_FILENAME)
#if !defined(FLORA_LOADDYN_DATA)
#define FLORA_LOADDYN_DATA
#endif
#mode save
#mode nocomment "%"
#define FLORA_FLS2_FILENAME  'a1_jain.fls2'
#mode restore
?-(:(flrutils,flora_loaddyn_data(FLORA_FLS2_FILENAME,FLORA_THIS_MODULE_NAME,'fls2'))).
#else
#if !defined(FLORA_READ_CANONICAL_AND_INSERT)
#define FLORA_READ_CANONICAL_AND_INSERT
#endif
?-(:(flrutils,flora_read_symbols_canonical_and_insert(FLORA_FLS2_FILENAME,FLORA_THIS_FLS_STORAGE,_SymbolErrNum))).
#endif

/************************************************************************
  file: headerinc/flrtrailer_inc.flh

  Author(s): Michael Kifer

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

#include "flrtrailer.flh"

/***********************************************************************/

/************************************************************************
  file: headerinc/flrpreddef_inc.flh

  Author(s): Chang Zhao

  This file is automatically included by the Flora-2 compiler.
************************************************************************/

:-(compiler_options([xpp_on])).

#include "flrpreddef.flh"

/***********************************************************************/

