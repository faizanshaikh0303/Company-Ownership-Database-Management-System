#! /bin/sh

rm -rf opt
rm -rf pkgs/.ergo_aux_files
rm -rf lib/.ergo_aux_files
rm -rf AT/.ergo_aux_files
rm -rf syslib/ergoisms
rm -rf genincludes/ergoisms
rm -rf flrincludes/ergoisms
rm -rf debugger/ergoisms
rm -rf closure/ergoisms
rm -rf ergo*
rm -rf docs/ergo*
rm -rf cc/ergo*
rm -rf cc/json
