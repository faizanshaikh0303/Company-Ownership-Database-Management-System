FLORADIR=/Users/Shubham/Desktop/SBU/DB/Flora-2/flora2
PROLOGDIR=/Users/Shubham/Desktop/SBU/DB/Flora-2/XSB/config/i386-apple-darwin16.7.0/bin
